export type MintResult = {
  digest: string;
  objectId: string | null;
};
